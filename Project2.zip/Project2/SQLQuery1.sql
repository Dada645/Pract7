USE master;
GO
DROP DATABASE Curs;
GO
CREATE DATABASE Curs;
GO
USE Curs;
GO

CREATE TABLE roles (
    role_id INT IDENTITY PRIMARY KEY,
    role_name NVARCHAR(50) UNIQUE NOT NULL
);
GO

INSERT INTO roles (role_name)
VALUES 
('Admin'),
('Agent'),
('Client');
GO

CREATE TABLE accounts (
    account_id INT IDENTITY PRIMARY KEY,
    username NVARCHAR(50) UNIQUE NOT NULL,
    password NVARCHAR(255) NOT NULL,
    role_id INT,
    CONSTRAINT fk_accounts_role
        FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE CASCADE
);
GO

INSERT INTO accounts (username, password, role_id)
VALUES 
('admin', 'admin', 1),
('petrov', 'hashed_password2', 2),
('sergeev', 'hashed_password3', 2);
GO

CREATE TABLE clients (
    client_id INT IDENTITY PRIMARY KEY,
    first_name NVARCHAR(100) NOT NULL,
    last_name NVARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    phone NVARCHAR(15),
    email NVARCHAR(100) UNIQUE,
    address NVARCHAR(MAX),
    account_id INT UNIQUE,
    CONSTRAINT fk_clients_account
        FOREIGN KEY (account_id) REFERENCES accounts(account_id) ON DELETE CASCADE
);
GO

CREATE TABLE employees (
    employee_id INT IDENTITY PRIMARY KEY,
    first_name NVARCHAR(100) NOT NULL,
    last_name NVARCHAR(100) NOT NULL,
    phone NVARCHAR(15),
    email NVARCHAR(100) UNIQUE,
    hire_date DATE NOT NULL,
    job_title NVARCHAR(50) NOT NULL,
    account_id INT UNIQUE,
    CONSTRAINT fk_employees_account
        FOREIGN KEY (account_id) REFERENCES accounts(account_id) ON DELETE CASCADE
);
GO

INSERT INTO employees (first_name, last_name, phone, email, hire_date, job_title, account_id)
VALUES 
('����', '������', '+79210000001', 'ivanov@example.com', '2023-01-15', 'Admin', 1),
('����', '������', '+79210000002', 'petrov@example.com', '2023-02-20', 'Agent', 2),
('������', '�������', '+79210000003', 'sergeev@example.com', '2023-03-10', 'Agent', 3);
GO

CREATE TABLE policies (
    policy_id INT IDENTITY PRIMARY KEY,
    policy_number NVARCHAR(50) UNIQUE NOT NULL,
    client_id INT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    premium_amount DECIMAL(10, 2) NOT NULL,
    coverage_amount DECIMAL(10, 2) NOT NULL,
    CONSTRAINT fk_policies_client
        FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE
);
GO

CREATE TABLE policy_types (
    type_id INT IDENTITY PRIMARY KEY,
    type_name NVARCHAR(50) UNIQUE NOT NULL,
    description NVARCHAR(MAX)
);
GO

CREATE TABLE policy_type_mapping (
    policy_type_mapping_id INT IDENTITY PRIMARY KEY,
    policy_id INT,
    type_id INT,
    CONSTRAINT fk_policy_mapping_policy
        FOREIGN KEY (policy_id) REFERENCES policies(policy_id) ON DELETE CASCADE,
    CONSTRAINT fk_policy_mapping_type
        FOREIGN KEY (type_id) REFERENCES policy_types(type_id) ON DELETE CASCADE
);
GO

CREATE TABLE claims (
    claim_id INT IDENTITY PRIMARY KEY,
    policy_id INT,
    incident_date DATE NOT NULL,
    claim_amount DECIMAL(10, 2) NOT NULL,
    description NVARCHAR(MAX),
    CONSTRAINT fk_claims_policy
        FOREIGN KEY (policy_id) REFERENCES policies(policy_id) ON DELETE CASCADE
);
GO

CREATE TABLE payouts (
    payout_id INT IDENTITY PRIMARY KEY,
    claim_id INT,
    payout_date DATE NOT NULL,
    payout_amount DECIMAL(10, 2) NOT NULL,
    CONSTRAINT fk_payouts_claim
        FOREIGN KEY (claim_id) REFERENCES claims(claim_id) ON DELETE CASCADE
);
GO

CREATE TABLE client_agents (
    client_agent_id INT IDENTITY PRIMARY KEY,
    client_id INT,
    employee_id INT,
    assigned_date DATE NOT NULL,
    CONSTRAINT fk_client_agents_client
        FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE NO ACTION,
    CONSTRAINT fk_client_employees_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE NO ACTION
);
GO

CREATE TABLE claim_status_history (
    history_id INT IDENTITY PRIMARY KEY,
    claim_id INT,
    status NVARCHAR(50) NOT NULL,
    change_date DATETIME DEFAULT GETDATE(),
    CONSTRAINT fk_claim_status_history_claim
        FOREIGN KEY (claim_id) REFERENCES claims(claim_id) ON DELETE CASCADE
);
GO

CREATE TABLE transactions (
    transaction_id INT IDENTITY PRIMARY KEY,
    client_id INT,
    transaction_date DATE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    description NVARCHAR(MAX),
    CONSTRAINT fk_transactions_client
        FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE
);
GO
